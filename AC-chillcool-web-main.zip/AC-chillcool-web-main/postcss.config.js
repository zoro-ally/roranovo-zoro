export default {
  plugins: {
    tailwindcss: {},
  },
}